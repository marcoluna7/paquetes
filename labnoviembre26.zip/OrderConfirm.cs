﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoeEcommers.LogicLayer.Modelos
{
    public class OrderConfirm
    {
        public int IdCard { get; set; }
        public string UserName { get; set; }
        public ShopingCars Car { get; set; }
    }
}
